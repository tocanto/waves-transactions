import { useState } from 'react';
import { IonButtons, IonButton, IonContent, IonModal, IonHeader, IonMenuButton, IonPage, IonTitle, IonToolbar, IonIcon, useIonToast, IonList, IonItemDivider, IonInput, IonItem, IonLabel, IonGrid, IonRow, IonCol, IonRadioGroup, IonRadio, IonListHeader } from '@ionic/react';
import { useParams } from 'react-router';
//import ExploreContainer from '../components/ExploreContainer';
import './MassTransfer.css';
import { hourglassOutline, hourglassSharp } from 'ionicons/icons';
// Importaciones Waves
import { Signer } from '@waves/signer';
import { ProviderKeeper } from '@waves/provider-keeper';

// Functional Component
const MassTransfer: React.FC = () => {

  // Parámetros del router
  const { name } = useParams<{ name: string; }>();

  // Modal
  const [isOpen, setIsOpen] = useState(false);

  // Toast notification
  const [present] = useIonToast();

  // Arreglo vacío para agregar las transferencias y sus montos
  const transfers: any = [];

  // ion inputs
  const [assetID, setAssetID] = useState<string>();
  const [attachment, setAttachment] = useState<string>('');
  const [address, setAddress] = useState<string>();
  const [amount, setAmount] = useState<string>();
  const [transfer, setTransfer] = useState(transfers);
  const [donationAmount, setDonationAmount] = useState<string>();

  // Conversión de monto donado (String to Number)
  const montoInput = (donado: any) => {
    const donado1 = Number(donado);
      return Number((donado1*(10**8)).toFixed());
  }

  const donation = montoInput(donationAmount);
  console.log(donation)

  // Para Base58Encode
  const base58 = require('base58-encode');

  // Manejador del envío de datos al arreglo
  const handleSubmit = (e: any) => {
    e.preventDefault();
    addTransfer(address, amount);
    setAddress('');
    setAmount('');
  }

  // Agrega las transferencias al arreglo vacío
  const addTransfer = ( address: any, amount: any ) => {
    let copy = [...transfer];
    const monto = Number(amount);
    copy = [...copy, { amount: Number((monto*(10**8)).toFixed()), recipient: address }];
    setTransfer(copy);
  }

  // Creación del objeto para la transferencia en masa
  const codificar = (adjunto: string) => {
    setAttachment(adjunto);
  }

  let data = {
    assetId: assetID,
    attachment: base58(attachment),
    transfers: transfer
  };

  // Función para generar el renderizado de las transferencias agregadas
  const transferencias = transfer.map((anObjectMapped: any, index: any) => {
    return (
          <IonRow key={`${anObjectMapped.recipient}_{anObjectMapped.amount}`}>
            <IonCol size="8">
              <IonItem>
                <IonLabel>{anObjectMapped.recipient}</IonLabel>
              </IonItem>
            </IonCol>
            <IonCol>
              <IonItem>
                <IonLabel>{(anObjectMapped.amount)/(10**8)}</IonLabel>
              </IonItem>
            </IonCol>
          </IonRow>
    );
})

  //Objeto que se transferirá en masa
  console.log(data)

  // Auth Function
const authFunc = async () => {
  setIsOpen(false);
  try {
    const userData = await signer.login();
    console.log(userData);
  } catch (e) {
    console.error('inicio de sesión rechazado')
  }
}

// Función de transferencia en masa
const massTransferTransaction = async () => {
  try {
    const [tx] = await signer
    .massTransfer(data)
    .broadcast();
    signer.waitTxConfirm(tx, 1).then((tx) => {
      // Tx have one confirmation
      console.log('Transacción confirmada');
      const confirmada = (() => {
        present('Transacción confirmada', 3000)
      })()
    });
  } catch (e) {
    console.error('transacción no enviada');
  }
}

//Función Donaciones
// Transfer Transaction
const transferTransaction = async (donacion: number) => {
  try {
    const [transfer] = await signer
    .transfer({
      recipient: direccion,
      amount: donacion*(10**8), // equals to 0.001 WAVES
      assetId: null, // equals to WAVES
    })
    .broadcast();
    signer.waitTxConfirm(transfer, 1).then((transfer) => {
      // Tx have one confirmation
      console.log('Transacción confirmada');
      const confirmada = (() => {
        present('Gracias por su donación', 3000)
      })()
    });
  } catch (e) {
    console.error('transacción no enviada');
  }
}

//Selección provider (testnet o mainnet)
const [selected, setSelected] = useState<string>('testnet');

let seleccionado = (selected==='testnet') ? 'https://nodes-testnet.wavesnodes.com' : 'https://nodes.wavesnodes.com';
let direccion = (selected==='testnet') ? '3MtcgyQa6DW4aSGVCzpub2FRBSAVb39a7yc' : '3P58vMvwJY1GUbdRwMK16KRGY4dcpjb24SR';

// Objeto Signer
const signer = new Signer({
  // Specify URL of the node on Testnet
  NODE_URL: seleccionado
});
const keeper = new ProviderKeeper();
signer.setProvider(keeper);

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonButtons slot="start">
            <IonMenuButton />
          </IonButtons>
          <IonButton slot="end" onClick={() => {setIsOpen(true)}}>
          Connect wallet
          </IonButton>
          <IonModal isOpen={isOpen}>
              <IonHeader>
                <IonToolbar>
                  <IonTitle>Connect wallet</IonTitle>
                    <IonButtons slot="end">
                      <IonButton onClick={() => setIsOpen(false)}>X</IonButton>
                    </IonButtons>
                </IonToolbar>
              </IonHeader>
              <IonContent className="ion-padding">
              <IonList>
                <IonRadioGroup value={selected} onIonChange={e => setSelected(e.detail.value)}>
                  <IonListHeader>
                    <IonLabel>Select Net</IonLabel>
                  </IonListHeader>

                  <IonItem>
                    <IonLabel>Testnet</IonLabel>
                    <IonRadio slot="start" value="testnet" />
                  </IonItem>

                  <IonItem>
                    <IonLabel>Mainnet</IonLabel>
                    <IonRadio slot="start" value="mainnet" />
                  </IonItem>

                </IonRadioGroup>
            </IonList>
                <IonButton onClick={ authFunc } expand="block" fill="outline">Waves Keeper
                <IonIcon slot="end" ios={hourglassOutline} md={hourglassSharp} /> 
                </IonButton>
              </IonContent>
          </IonModal>
          <IonTitle>{name}</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonItemDivider></IonItemDivider>
      <IonContent fullscreen>
        <IonHeader collapse="condense">
          <IonToolbar>
            <IonTitle size="large">{name}</IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonList>
          <IonItem>
            <IonLabel position="floating">Asset id</IonLabel>
            <IonInput value={assetID} onIonChange={e => setAssetID(e.detail.value!)} clearInput></IonInput>
          </IonItem>
          <IonItem>
            <IonLabel position="floating">Attachment</IonLabel>
            <IonInput value={attachment} onIonChange={e => setAttachment(e.detail.value!)} onIonBlur={e => codificar((String(e.target.value)))} clearInput></IonInput>
          </IonItem>
        </IonList>
        <IonGrid>
        <form onSubmit={ handleSubmit }>
          <IonRow>
            <IonCol size="8">
            <IonItem>
            <IonInput value={address} placeholder="Address" onIonChange={e => setAddress(e.detail.value!)} clearInput></IonInput>
          </IonItem>
            </IonCol>
            <IonCol>
            <IonItem>
            <IonInput value={amount} placeholder="Amount" onIonChange={e => setAmount(e.detail.value!)} clearInput></IonInput>
          </IonItem>
            </IonCol>
            <IonCol>
              <IonButton type='submit'>+</IonButton>
            </IonCol>
          </IonRow>
        </form>
        </IonGrid>
        <IonItemDivider></IonItemDivider>
        <IonContent>
          <IonRow>
            <IonCol size="4">
            </IonCol>
            <IonCol>
            <IonLabel>Addresses added</IonLabel>
            </IonCol>
            <IonCol></IonCol>
          </IonRow>
          {/*-- List of Text Items --*/}
          <IonList>
          { transferencias }
          </IonList>
          <IonGrid>
            <IonRow>
              <IonCol size="4">
              </IonCol>
              <IonCol size="6">
                <IonButton onClick={ massTransferTransaction }>Enviar</IonButton>
              </IonCol>
            </IonRow>
          </IonGrid>
          <IonItemDivider></IonItemDivider>
          <IonGrid>
            <IonRow>
              <IonCol size="4">
              </IonCol>
              <IonCol size="8">
                <IonLabel>Donate crypto to the author!</IonLabel>
              </IonCol>
            </IonRow>
            </IonGrid>
            <IonGrid>
            <IonRow>
              <IonCol size="4">
              </IonCol>
              <IonCol size="8">
                <IonButton size="small" onClick={ () => transferTransaction(0.10) }>
                  0.10
                  <span className="waves__logo"></span>
                </IonButton>
                <IonButton size="small" onClick={ () => transferTransaction(1) }>
                  1
                  <span className="waves__logo"></span>
                </IonButton>
                <IonButton size="small" onClick={ () => transferTransaction(5) }>
                  5
                  <span className="waves__logo"></span>
                </IonButton>  
                <IonButton size="small" onClick={ () => transferTransaction(Number((donation)/(10**8))) }>
                  <IonInput className='boton' value={donationAmount} placeholder="Amount" onIonChange={e => setDonationAmount(e.detail.value!)} clearInput></IonInput>
                  <span className="waves__logo"></span>
                </IonButton>
              </IonCol>
            </IonRow>
            </IonGrid>
        </IonContent>
      </IonContent>
    </IonPage>
  );
};

export default MassTransfer;